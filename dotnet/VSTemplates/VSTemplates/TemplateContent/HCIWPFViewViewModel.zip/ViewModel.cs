﻿using Net.Homecredit.Infrastructure.Module.WPF.MVVM;
using Net.Homecredit.Infrastructure.Module.WPF.Validations;

namespace $rootnamespace$.$fileinputname$
{
    public class $fileinputname$ViewModel : BaseViewModel
    {
        #region Overrides of BaseViewModel

        public override void BindData(params object[] bindViewParameters)
        {
            base.BindData(bindViewParameters);
        }

        public override void OnLoad()
        {
            base.OnLoad();
        }

        protected override void ValidateCustom(ValidationResultCollection validationResults)
        {
            base.ValidateCustom(validationResults);
        }

        #endregion
    }
}
